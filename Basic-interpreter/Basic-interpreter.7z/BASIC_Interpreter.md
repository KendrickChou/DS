# BASIC_Interpreter

* Day 1 - 2021/3/2
  1. Read Basic-doc

  2. Construct the framwork

* Day 2 - 2021/3/3
  1. Complete input and edit function by command.

* Day3 - 2021/3/4 (my 20th Birthday!)
  1. Complete file load fuction.
  2. Construct the framwork of class eval ,parse ,and tokenizer.